import org.junit.Assert;
import org.junit.Rule;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

class triangleTest {
    triangle Triangle=new triangle();

    @Test
    void judgeTriangle() {
        int result=Triangle.JudgeTriangle(1,2,3);
        Assert.assertEquals("1,2,3casefailed",0,result);
        result=Triangle.JudgeTriangle(0,2,3);
        Assert.assertEquals("0,2,3casefailed",0,result);
        result=Triangle.JudgeTriangle(0,0,0);
        Assert.assertEquals("0,0,0casefailed",0,result);
        result=Triangle.JudgeTriangle(4,0,-3);
        Assert.assertEquals("4,0,-3casefailed",0,result);
        result=Triangle.JudgeTriangle(4,5,6);
        Assert.assertEquals("4,5,6casefailed",1,result);
    }

    @Test
    void judgeDTriangle() {
        int result=Triangle.JudgeDTriangle(2,2,0);
        Assert.assertEquals("2,2,0casefailed",0,result);
        result=Triangle.JudgeDTriangle(2,2,-1);
        Assert.assertEquals("2,2,-1casefailed",0,result);
        result=Triangle.JudgeDTriangle(-1,-1,-1);
        Assert.assertEquals("-1,-1,-1casefailed",0,result);
        result=Triangle.JudgeDTriangle(-3,-3,1);
        Assert.assertEquals("-3,-3,1casefailed",0,result);

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        result=Triangle.JudgeDTriangle(1,1,1);
        Assert.assertEquals("1,1,1casefailed",1,result);
        String expectedOutput  = "该三角形是等边三角形！\r\n";
        assertEquals(expectedOutput, outContent.toString());

        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        result=Triangle.JudgeDTriangle(2,2,1);
        Assert.assertEquals("2,2,1casefailed",1,result);
        expectedOutput="该三角形是普通的等腰三角形！\r\n";
        assertEquals(expectedOutput, outContent.toString());



    }

    @Test
    void judgeRTriangle() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        int result=Triangle.JudgeRTriangle(3,4,5);
        Assert.assertEquals("3,4,5casefailed",1,result);
        String expectedOutput  = "该三角形是直角三角形！\r\n";
        assertEquals(expectedOutput, outContent.toString());

        result=Triangle.JudgeRTriangle(-3,-4,5);
        Assert.assertEquals("-3,-4,5casefailed",0,result);

        result=Triangle.JudgeRTriangle(-3,-4,-5);
        Assert.assertEquals("-3,-4,-5casefailed",0,result);

        result=Triangle.JudgeRTriangle(2,3,4);
        Assert.assertEquals("2,3,4casefailed",0,result);

        result=Triangle.JudgeRTriangle(1,2,3);
        Assert.assertEquals("1,2,3casefailed",0,result);
    }

    @Test
    void main() {
    }
}